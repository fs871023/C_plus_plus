學號:406315017
姓名:鄧智宇
環境(哪一台工作站):linux.cs.ccu.edu.tw
E-mail:fs871023@gmail.com
簡介:在main函式裡讀檔後，傳入display函式裡。
display函式中，把陣列傳入計算平均和最大值的函式，再印出來
readlist函式則負責把陣列的東西列出來，但因作業沒有要求所以未放入main中。

