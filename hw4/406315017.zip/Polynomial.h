#define NodePointer Node*
typedef int CoefType;// term in a polynomial
class Term
{
public:
    CoefType coef;
    int expo;
};
// node in a linked list
class Node
{
private:
    Term data;
    NodePointer next;
public:// node constructor
    Node(CoefType, int, Node *);
    friend class Polynomial;
};
// polynomial ADT
class Polynomial
{
private:
    NodePointer head; // pointing to the first dummy node
public:// constructor
    Polynomial (CoefType*, int*, int );
// destructor
    ~Polynomial();// add a term into the polynomial
    void add (CoefType, int ); // differentiation
    void differentiate();
    const void printPolynomial() const;
};
